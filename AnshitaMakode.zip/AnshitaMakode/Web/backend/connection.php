<?php
$host = "localhost";
$user= "root";
$pwd = "";
$database = "webdb";

try {
    $conn = new PDO("mysql:host=$host; dbname=$database", $user, $pwd, array( PDO::ATTR_PERSISTENT => true ));
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //echo "Connection established";
}
catch(PDOException $e)
{
    throw new Exception();
}

?>