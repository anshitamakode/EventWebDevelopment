<?php


session_start();
try {

    if (!file_exists('../connection.php' ))
        throw new Exception();
    else
        require_once('../connection.php' ); 
		
} catch (Exception $e) {

	$_SESSION['msg'] = 'There were some problem in the Server! Try after some time!';

	header('location: ../../admin/event-list.php');

	exit();
	
}

if (!isset($_POST['name']) || !isset($_POST['desc']) || !isset($_POST['dateandtime']) || !isset($_POST['place'])) {

	$_SESSION['msg'] = 'Invalid POST variable keys! Refresh the page!';

	header('location: ../../admin/event-list.php');

	exit();
}

$regex = '/^[(A-Z)?(a-z)?(0-9)?\-?\_?\.?\s*]+$/';


if (!preg_match($regex, $_POST['name']) || !preg_match($regex, $_POST['desc'])) {

	$_SESSION['msg'] = 'Whoa! Invalid Inputs!';

	header('location: ../../admin/event-list.php');

	exit();

} else {

	$name = $_POST['name'];
	$desc = $_POST['desc'];
    $category = $_POST['category'];
    $dt = $_POST['dateandtime'];
    $location = $_POST['place'];
	$sql = "INSERT INTO event(cat_id,ename,description,dateandtime,place) VALUES(?,?,?,?,?)";
    $query  = $conn->prepare($sql);
    if ($query->execute([$category, $name, $desc, $dt, $location])) {

    	$_SESSION['msg'] = 'Event Added!';

		header('location: ../../admin/event-list.php');
    	
    } else {

    	$_SESSION['msg'] = 'There were some problem in the server! Please try again after some time!';

		header('location: ../../admin/event-list.php');

    }


}