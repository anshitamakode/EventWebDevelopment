A web application project of events in php.

To run the main site
url : localhost/Anshita

For admin registraton and login
Click on Admin




