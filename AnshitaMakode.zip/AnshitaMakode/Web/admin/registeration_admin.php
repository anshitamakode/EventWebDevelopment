<?php
include_once("../backend/connection.php");

if (var_dump(!isset($_POST['submit'])))
{
    $_SESSION['msg'] = 'Invalid POST variable keys! Refresh the page!';
    header('location: index_reg.php');
    exit();
}

$name=$_POST['name'];
$email=$_POST['email'];
$password=$_POST['password'];

$sql = "INSERT INTO admin(name,email,password) VALUES(?,?,?)";

$query  = $conn->prepare($sql);


if ($query->execute([$name,$email,$password])) {
    
    $_SESSION['msg']="You have successfully Registered!";
    header('location: index.php');

} else {
	session_start();
	$_SESSION['msg']="Invalid Credentials!";
	header('location: index_reg.php');
}



?>