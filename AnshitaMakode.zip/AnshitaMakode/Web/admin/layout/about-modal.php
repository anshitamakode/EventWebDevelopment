<div id="modal1" class="modal">
    <div class="modal-content">
        <h4>About</h4>
        <?php 
            echo '<h5>'.$_SESSION['about'].'</h5>';
        ?>
    </div>
    <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Close</a>
    </div>
  </div>