<div class="row">
			
			<div class="col s2 left-sidebar" id="left-sidebar">

				<div class="row">
					<div class="col">
						<?php 
                            echo '<h3>&nbsp&nbsp&nbsp'.$_SESSION['username'].'</h3>'
                        ?>
					</div>
				</div>
				<ul class="nav nav-sidebar list-group">
				    <li class="list-group-item active"><a href="event-list.php">Events</a></li>
				    <li class="list-group-item"><a href="category-list.php">Category</a></li>
				  </ul>
			</div>