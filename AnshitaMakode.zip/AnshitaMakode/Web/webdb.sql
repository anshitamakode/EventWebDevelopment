-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 30, 2020 at 12:21 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`) VALUES
(6, 'Anshita Makode', 'anshita@gmail.com', 'anshita');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `short_desc` varchar(500) NOT NULL,
  `long_desc` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `short_desc`, `long_desc`) VALUES
(1, 'Webinar', 'The word webinar is a blend of web and seminar.', 'A webinar is an event held on the internet which is attended exclusively by an online audience.'),
(2, 'Seminar', 'A seminar is a form of academic instruction, either at an academic institution or offered by a commercial or professional organization.', ' It has the function of bringing together small groups for recurring meetings, focusing each time on some particular subject, in which everyone present is requested to participate.'),
(3, 'BloodDonation', 'Blood donation is a voluntary procedure that can help save the lives of others.', 'A blood donation occurs when a person voluntarily has blood drawn and used for transfusions and made into biopharmaceutical medications by a process called fractionation.'),
(4, 'GeneralSocietyMeet', 'A Special General Body Meeting of the Society may be called at any time at the instance of the Chairman', 'The meeting so convened shall not transact any business, other than that mentioned in the Notice of the Meeting, fixing date, time and place for a Special General Body Meeting requisitioned.');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `ename` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `dateandtime` varchar(100) NOT NULL,
  `place` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`id`, `cat_id`, `ename`, `description`, `dateandtime`, `place`) VALUES
(1, 1, 'Managing the Virtual Experience', 'This event is all about to talk business with event professionals willing to transition their events to online experiences.', '1 July 2020, 9 to 11 am', 'Pune'),
(2, 1, 'The Rise of the Event Technologist', 'There is a new breed of event professionals who understand meetings and technology at the same level of depth.', '3 July 2020, 5 to 9 pm', 'Chennai'),
(3, 2, 'How to Become an Event Strategist', 'How can you progress your career in a clime of uncertainty? EventMB recently completed a comprehensive research into what hiring managers want for candidates applying for top planning roles.', '11 July 2020, 2 to 4 pm', 'Indore'),
(4, 2, 'Event Trends 2020', 'IMEX is the largest and most influential trade show of the meetings and event industry.', '23 August 2020, 6 to 9 pm', 'Nagpur'),
(5, 3, 'Yuva Bengaluru', 'Blood donation is among the highest service one can render to humanity.', '27 Nov 2020, 7 to 9 pm', 'Bengalore'),
(6, 4, 'Vishwakarma society meet', 'It is a society meet going to be conducted to discuss society related issues.', '30 Sep 2020, 10 to 11 am', 'Pune');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password`) VALUES
(1, 'Avanti Darekar', 'avanti@gmail.com', 'avanti');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
